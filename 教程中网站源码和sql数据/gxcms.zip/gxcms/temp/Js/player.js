var player_width=610;var player_height=458;var player_down="http://union.gxcms.com/app/player.php";var player_buffer="http://union.gxcms.com/app/buffer.html";var player_time="8";var player_pause="";
